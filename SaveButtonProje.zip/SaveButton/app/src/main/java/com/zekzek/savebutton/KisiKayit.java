package com.zekzek.savebutton;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.zekzek.savebutton.databinding.ActivityDepremsayfaBinding;
import com.zekzek.savebutton.databinding.ActivityKisiKayitBinding;
import com.zekzek.savebutton.databinding.ActivityMainBinding;

import java.util.ArrayList;

public class KisiKayit extends AppCompatActivity {

    ActivityKisiKayitBinding binding;

    ListView listofPerson;
    ArrayList<String> PersonList;
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kisi_kayit);
        binding = ActivityKisiKayitBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);
        listofPerson = binding.Listview;


        PersonList = new ArrayList<>();
        adapter = new ArrayAdapter<>(KisiKayit.this, android.R.layout.simple_list_item_1, android.R.id.text1,PersonList);
        listofPerson.setAdapter(adapter);

        binding.btnKayit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                String newItem=binding.btnAd.getText().toString() + "  Adres:"+ binding.btnAdres.getText().toString();
                PersonList.add(newItem);
                adapter.notifyDataSetChanged();

                binding.btnAd.setText("");
                binding.btnAdres.setText("");

            }
        });

        listofPerson.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String selectedItem = PersonList.get(i);
                //Toast.makeText(KisiKayit.this, "Selected item: " + selectedItem, Toast.LENGTH_SHORT).show();
                String message = selectedItem;
//              String message = "Ad: " + isim + "\nSoyad: " + soyisim + "\nAdres: İstanbul \nMesaj: AFET YARDIM BİLDİRİMİ";
                String phoneNumber = "05555555555";
                Intent smsIntent = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + phoneNumber));
                smsIntent.putExtra("sms_body", message);
                startActivity(smsIntent);
            }
        });
    }
}