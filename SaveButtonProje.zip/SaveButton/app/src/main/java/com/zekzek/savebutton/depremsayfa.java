package com.zekzek.savebutton;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

import com.zekzek.savebutton.databinding.ActivityDepremsayfaBinding;
import com.zekzek.savebutton.databinding.ActivityDepremsayfaBinding;

public class depremsayfa extends AppCompatActivity {


    ActivityDepremsayfaBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_depremsayfa);

        binding = ActivityDepremsayfaBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);

        binding.WebView.loadUrl("https://deprem.afad.gov.tr/last-earthquakes.html");






    }
}