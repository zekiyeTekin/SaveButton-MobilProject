package com.zekzek.savebutton;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;

import java.text.SimpleDateFormat;
import java.util.Date;
import android.media.MediaPlayer;

import com.zekzek.savebutton.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    ActivityMainBinding binding;
    private SQLiteDatabase database;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        //setContentView(R.layout.activity_main);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        View view = binding.getRoot();
        setContentView(view);

        SimpleDateFormat sekil = new SimpleDateFormat();
        Date tarih = new Date();
        binding.txtSaat.setText(tarih.toString());


        final MediaPlayer ses = MediaPlayer.create(this, R.raw.duduk);

        binding.btnZil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View zil) {
                ses.start();
            }
        });
        binding.btnDeprem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View deprem) {
                Intent intent = new Intent(MainActivity.this, depremsayfa.class);
                startActivity(intent);
            }
        });

        binding.btnAra.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Intent.ACTION_DIAL);
                i.setData(Uri.parse("tel:5399114746"));
                startActivity(i);
            }
        });
       binding.btnKisi.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View kisi) {
               /* String message = "Ad: Ali\nSoyad: Yılmaz\nAdres: İstanbul \nMesaj:AFET YARDIM BİLDİRİMİ";
//              String message = "Ad: " + isim + "\nSoyad: " + soyisim + "\nAdres: İstanbul \nMesaj: AFET YARDIM BİLDİRİMİ";
                String phoneNumber = "05399114746";
                Intent smsIntent = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + phoneNumber));
                smsIntent.putExtra("sms_body", message);
                startActivity(smsIntent);*/
               Intent intent = new Intent(MainActivity.this, KisiKayit.class);
               startActivity(intent);

           }
       });






    }

}





